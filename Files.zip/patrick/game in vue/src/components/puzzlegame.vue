<template>
  <div class="header">
    <h1>THIS IS OUR FIRST VUE</h1>
  </div>
  <p>Click on a tile to complete the puzzle</p>

  <div class="grid">
    <div
      class="tile"
      v-for="(tile, index) in tiles"
      :key="index"
      :style="tile !== null ? getTileStyle(tile) : { backgroundColor: '#fff' }"
      @click="moveTile(index)"
    >
      <span v-if="tile !== null">{{ tile + 1 }}</span>
    </div>
  </div>

  <div class="buttons">
    <button @click="shuffleTiles" class="shuffle">Mix it</button>
    <button @click="solvePuzzle" class="solve">Solve Puzzle</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";

// Puzzle images
const figures = [
  {
    name: 'Hero 1',
    fact: 'This is a hero, he is the one who RPA',
    image: './image/figure1.jpg'
  },
  {
    name: 'Hero 2',
    fact: 'This is a hero, he is the king Leo III',
    image: './image/figure2.jpg'
  },
    {
    name: 'Hero 3',
    fact: 'This is a hero, he is the king Rudahigwa Mudahigwa',
    image: './image/figure3.jpg'}
    {
name: 'Hero 4',
fact: 'This is a hero, he is the H.E Paul Kagame' ,
image: './image/figure4.jpg'}
];

const currentFigureIndex = ref(0);
const currentFigure = ref(figures[currentFigureIndex.value]);

const tiles = ref([]);
const isCompleted = ref(false);
const emptyIndex = ref(8);

// Set puzzle to solved state
function initializeTiles() {
  tiles.value = Array.from({ length: 8 }, (_, i) => i).concat(null);
  emptyIndex.value = 8;
  isCompleted.value = false;
  currentFigure.value = figures[currentFigureIndex.value];
}

// Shuffle the puzzle
function shuffleTiles() {
  const shuffled = Array.from({ length: 8 }, (_, i) => i).concat(null);
  tiles.value = shuffleArray(shuffled);
  emptyIndex.value = tiles.value.indexOf(null);
  isCompleted.value = false;
}

function shuffleArray(arr) {
  let currentIndex = arr.length;
  while (currentIndex !== 0) {
    const randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [arr[currentIndex], arr[randomIndex]] = [arr[randomIndex], arr[currentIndex]];
  }
  return arr;
}

function moveTile(index) {
  const validMoves = [1, -1, 3, -3];
  for (const move of validMoves) {
    if (index + move === emptyIndex.value) {
      [tiles.value[index], tiles.value[emptyIndex.value]] = [tiles.value[emptyIndex.value], tiles.value[index]];
      emptyIndex.value = index;
      checkCompletion();
      return;
    }
  }
}

// ✅ Check if puzzle is complete and change image
function checkCompletion() {
  for (let i = 0; i < tiles.value.length - 1; i++) {
    if (tiles.value[i] !== i) return;
  }
  if (tiles.value[8] === null) {
    isCompleted.value = true;
    alert("🎉 Congz! You've completed the puzzle!");

    // Move to next figure
    currentFigureIndex.value = (currentFigureIndex.value + 1) % figures.length;
    currentFigure.value = figures[currentFigureIndex.value];

    // Reset puzzle with new image
    setTimeout(() => {
      initializeTiles();
    }, 500);
  }
}

function solvePuzzle() {
  tiles.value = Array.from({ length: 8 }, (_, i) => i).concat(null);
  emptyIndex.value = 8;
  isCompleted.value = false;
}

function getTileStyle(tileIndex) {
  const row = Math.floor(tileIndex / 3);
  const col = tileIndex % 3;
  return {
    backgroundImage: `url(${currentFigure.value.image})`,
    backgroundPosition: `-${col * 100}px -${row * 100}px`,
    backgroundSize: '300px 300px',
    width: '100px',
    height: '100px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#fff',
    fontSize: '24px',
    fontWeight: 'bold',
    border: '1px solid #000',
    cursor: 'pointer'
  };
}

onMounted(() => {
  initializeTiles();
});
</script>

<style>
.grid {
  display: grid;
  grid-template-columns: repeat(3, 100px);
  grid-template-rows: repeat(3, 100px);
  gap: 5px;
  margin: 20px auto;
  padding: 20px;
  background-color: black;
  width: max-content;
}

.tile {
  background-color: #ccc;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: bold;
  font-size: 20px;
  height: 100px;
  width: 100px;
}

.buttons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 20px;
}

.shuffle,
.solve {
  padding: 10px 20px;
  font-weight: bold;
  border: none;
  cursor: pointer;
  color: white;
  border-radius: 5px;
}

.shuffle {
  background-color: #007bff;
}
.shuffle:hover {
  background-color: #0069d9;
}

.solve {
  background-color: #28a745;
}
.solve:hover {
  background-color: #218838;
}

.header h1 {
  text-align: center;
  margin-top: 20px;
}
</style>
