


<script setup>
import puzzlegame from "./components/puzzlegame.vue";
</script>


<template>
    <puzzlegame/>
</template>















